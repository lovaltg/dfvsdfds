// Типы для маркетплейса GameMarket

export interface Profile {
  id: string;
  username: string;
  avatar_url: string | null;
  email: string;
  created_at: string;
  last_online: string;
  nickname_changed_at: string | null;
  balance: number;
  is_online?: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string | null;
  type: 'game' | 'app' | 'service';
  parent_id: string | null;
  order: number;
  image_url?: string | null;
  is_new?: boolean;
}

export interface Subcategory {
  id: string;
  category_id: string;
  name: string;
  slug: string;
  icon: string | null;
}

export interface Lot {
  id: string;
  seller_id: string;
  category_id: string;
  subcategory_id: string;
  title: string;
  description: string;
  price: number;
  old_price: number | null;
  quantity: number;
  status: 'active' | 'sold' | 'archived';
  created_at: string;
  updated_at: string;
  images: string[];
  seller?: Profile;
  category?: Category;
  subcategory?: Subcategory;
  reviews_count?: number;
  rating?: number;
}

export interface Order {
  id: string;
  order_number: string;
  buyer_id: string;
  seller_id: string;
  lot_id: string;
  amount: number;
  status: 'pending' | 'paid' | 'completed' | 'cancelled' | 'disputed';
  created_at: string;
  completed_at: string | null;
  buyer?: Profile;
  seller?: Profile;
  lot?: Lot;
}

export interface Transaction {
  id: string;
  user_id: string;
  type: 'deposit' | 'withdrawal' | 'payment' | 'refund';
  amount: number;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  payment_method: string | null;
  description: string | null;
  created_at: string;
  order_id?: string | null;
}

export interface Chat {
  id: string;
  participant_1: string;
  participant_2: string;
  created_at: string;
  last_message_at: string;
  participant_1_profile?: Profile;
  participant_2_profile?: Profile;
  last_message?: Message;
  unread_count?: number;
}

export interface Message {
  id: string;
  chat_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  is_read: boolean;
  sender?: Profile;
}

export interface Review {
  id: string;
  order_id: string;
  reviewer_id: string;
  reviewed_id: string;
  rating: number;
  comment: string;
  created_at: string;
  reviewer?: Profile;
}

export interface TopSeller {
  id: string;
  username: string;
  avatar_url: string | null;
  sales_count: number;
  positive_reviews: number;
  rating: number;
}

export type Theme = 'light' | 'dark';
