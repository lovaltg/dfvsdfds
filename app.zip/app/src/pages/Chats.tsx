import { useEffect, useState, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase, getOrCreateChat, getMessages, sendMessage } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import {
  MessageSquare,
  Send,
  ArrowLeft,
  User,
} from 'lucide-react';
import type { Message } from '@/types';

interface ChatWithProfiles {
  id: string;
  participant_1: string;
  participant_2: string;
  created_at: string;
  last_message_at: string;
  participant_1_profile?: {
    id: string;
    username: string;
    avatar_url: string | null;
    is_online?: boolean;
  };
  participant_2_profile?: {
    id: string;
    username: string;
    avatar_url: string | null;
    is_online?: boolean;
  };
  last_message?: {
    content: string;
    created_at: string;
  };
}

export function Chats() {
  const { user, profile } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const [chats, setChats] = useState<ChatWithProfiles[]>([]);
  const [selectedChat, setSelectedChat] = useState<ChatWithProfiles | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatId = searchParams.get('chat');
  const userId = searchParams.get('user');

  useEffect(() => {
    if (user) {
      loadChats();
    }
  }, [user]);

  useEffect(() => {
    if (chatId && user) {
      loadChatMessages(chatId);
    } else if (userId && user) {
      createChatWithUser(userId);
    }
  }, [chatId, userId, user]);

  useEffect(() => {
    // Subscribe to new messages
    if (selectedChat && user) {
      const subscription = supabase
        .channel(`chat:${selectedChat.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `chat_id=eq.${selectedChat.id}`,
          },
          (payload) => {
            const newMsg = payload.new as Message;
            if (newMsg.sender_id !== user.id) {
              setMessages((prev) => [...prev, newMsg]);
              scrollToBottom();
            }
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [selectedChat, user]);

  const loadChats = async () => {
    if (!user) return;

    try {
      const { data } = await supabase
        .from('chats')
        .select(`
          *,
          participant_1_profile:profiles!chats_participant_1_fkey(*),
          participant_2_profile:profiles!chats_participant_2_fkey(*)
        `)
        .or(`participant_1.eq.${user.id},participant_2.eq.${user.id}`)
        .order('last_message_at', { ascending: false });

      if (data) {
        setChats(data as unknown as ChatWithProfiles[]);
      }
    } catch (error) {
      console.error('Error loading chats:', error);
    } finally {
      setLoading(false);
    }
  };

  const createChatWithUser = async (targetUserId: string) => {
    if (!user) return;

    const { data: chat } = await getOrCreateChat(user.id, targetUserId);
    if (chat) {
      setSearchParams({ chat: chat.id });
    }
  };

  const loadChatMessages = async (chatId: string) => {
    setLoadingMessages(true);
    try {
      const { data: chatData } = await supabase
        .from('chats')
        .select(`
          *,
          participant_1_profile:profiles!chats_participant_1_fkey(*),
          participant_2_profile:profiles!chats_participant_2_fkey(*)
        `)
        .eq('id', chatId)
        .single();

      if (chatData) {
        setSelectedChat(chatData as unknown as ChatWithProfiles);
      }

      const { data: messagesData } = await getMessages(chatId);
      if (messagesData) {
        setMessages(messagesData);
        scrollToBottom();
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoadingMessages(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedChat || !user) return;

    const messageContent = newMessage.trim();
    setNewMessage('');

    // Optimistically add message
    const optimisticMessage: Message = {
      id: 'temp-' + Date.now(),
      chat_id: selectedChat.id,
      sender_id: user.id,
      content: messageContent,
      created_at: new Date().toISOString(),
      is_read: false,
      sender: profile || undefined,
    };
    setMessages((prev) => [...prev, optimisticMessage]);
    scrollToBottom();

    // Send to server
    const { data, error } = await sendMessage(selectedChat.id, user.id, messageContent);
    if (error) {
      // Remove optimistic message on error
      setMessages((prev) => prev.filter((m) => m.id !== optimisticMessage.id));
      alert('Ошибка при отправке сообщения');
    } else if (data) {
      // Replace optimistic message with real one
      setMessages((prev) =>
        prev.map((m) => (m.id === optimisticMessage.id ? data : m))
      );
    }
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const getOtherParticipant = (chat: ChatWithProfiles) => {
    if (!user) return null;
    return chat.participant_1 === user.id
      ? chat.participant_2_profile
      : chat.participant_1_profile;
  };

  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString('ru-RU', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDate = (date: string) => {
    const msgDate = new Date(date);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (msgDate.toDateString() === today.toDateString()) {
      return 'Сегодня';
    } else if (msgDate.toDateString() === yesterday.toDateString()) {
      return 'Вчера';
    } else {
      return msgDate.toLocaleDateString('ru-RU');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Требуется авторизация</h1>
          <p className="text-muted-foreground mb-6">
            Войдите в аккаунт, чтобы использовать чаты
          </p>
          <Button onClick={() => navigate('/auth')}>Войти</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-12rem)]">
          {/* Chats List */}
          <Card className={`lg:col-span-1 ${selectedChat ? 'hidden lg:flex' : 'flex'} flex-col`}>
            <div className="p-4 border-b">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Чаты
              </h2>
            </div>
            <ScrollArea className="flex-1">
              {loading ? (
                <div className="p-4 space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-3">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-32" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : chats.length > 0 ? (
                <div className="divide-y">
                  {chats.map((chat) => {
                    const otherUser = getOtherParticipant(chat);
                    return (
                      <button
                        key={chat.id}
                        onClick={() => setSearchParams({ chat: chat.id })}
                        className={`w-full p-4 flex items-center gap-3 hover:bg-muted transition-colors text-left ${
                          selectedChat?.id === chat.id ? 'bg-muted' : ''
                        }`}
                      >
                        {otherUser?.avatar_url ? (
                          <img
                            src={otherUser.avatar_url}
                            alt={otherUser.username}
                            className="h-10 w-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-sm font-bold text-primary">
                              {otherUser?.username?.charAt(0) || '?'}
                            </span>
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate">
                            {otherUser?.username || 'Пользователь'}
                          </div>
                          <div className="text-sm text-muted-foreground truncate">
                            {chat.last_message?.content || 'Нет сообщений'}
                          </div>
                        </div>
                        {chat.last_message && (
                          <span className="text-xs text-muted-foreground">
                            {formatTime(chat.last_message.created_at)}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">У вас пока нет чатов</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Начните общение с продавцом на странице лота
                  </p>
                </div>
              )}
            </ScrollArea>
          </Card>

          {/* Chat Window */}
          <Card className={`lg:col-span-2 ${selectedChat ? 'flex' : 'hidden lg:flex'} flex-col`}>
            {selectedChat ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="lg:hidden"
                    onClick={() => setSearchParams({})}
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                  {(() => {
                    const otherUser = getOtherParticipant(selectedChat);
                    return (
                      <>
                        {otherUser?.avatar_url ? (
                          <img
                            src={otherUser.avatar_url}
                            alt={otherUser.username}
                            className="h-10 w-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <User className="h-5 w-5 text-primary" />
                          </div>
                        )}
                        <div>
                          <div className="font-medium">{otherUser?.username}</div>
                          <div className="text-xs text-muted-foreground">
                            {otherUser?.is_online ? 'Онлайн' : 'Офлайн'}
                          </div>
                        </div>
                      </>
                    );
                  })()}
                </div>

                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  {loadingMessages ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className={`flex ${i % 2 === 0 ? 'justify-end' : ''}`}>
                          <Skeleton className={`h-12 w-48 rounded-2xl`} />
                        </div>
                      ))}
                    </div>
                  ) : messages.length > 0 ? (
                    <div className="space-y-4">
                      {messages.map((message, index) => {
                        const isOwn = message.sender_id === user.id;
                        const showDate =
                          index === 0 ||
                          formatDate(messages[index - 1].created_at) !==
                            formatDate(message.created_at);

                        return (
                          <div key={message.id}>
                            {showDate && (
                              <div className="flex justify-center my-4">
                                <Badge variant="secondary" className="text-xs">
                                  {formatDate(message.created_at)}
                                </Badge>
                              </div>
                            )}
                            <div
                              className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                            >
                              <div
                                className={`max-w-[70%] px-4 py-2 rounded-2xl ${
                                  isOwn
                                    ? 'bg-primary text-primary-foreground'
                                    : 'bg-muted'
                                }`}
                              >
                                <p>{message.content}</p>
                                <span
                                  className={`text-xs mt-1 block ${
                                    isOwn ? 'text-primary-foreground/70' : 'text-muted-foreground'
                                  }`}
                                >
                                  {formatTime(message.created_at)}
                                </span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </div>
                  ) : (
                    <div className="h-full flex items-center justify-center">
                      <div className="text-center">
                        <MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <p className="text-muted-foreground">Нет сообщений</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          Напишите первое сообщение
                        </p>
                      </div>
                    </div>
                  )}
                </ScrollArea>

                {/* Message Input */}
                <div className="p-4 border-t">
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Введите сообщение..."
                      className="flex-1"
                    />
                    <Button type="submit" size="icon">
                      <Send className="h-4 w-4" />
                    </Button>
                  </form>
                </div>
              </>
            ) : (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">Выберите чат</h3>
                  <p className="text-muted-foreground">
                    Выберите чат из списка слева, чтобы начать общение
                  </p>
                </div>
              </div>
            )}
          </Card>
        </div>
      </main>
    </div>
  );
}
