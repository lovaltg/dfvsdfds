import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { CategoryCard } from '@/components/CategoryCard';
import { LotCard } from '@/components/LotCard';
import { TopSellers } from '@/components/TopSellers';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Gamepad2, Smartphone, MessageCircle, ChevronRight, ExternalLink, AlertTriangle } from 'lucide-react';
import type { Category, Lot } from '@/types';

export function Home() {
  const [games, setGames] = useState<Category[]>([]);
  const [apps, setApps] = useState<Category[]>([]);
  const [mobileGames, setMobileGames] = useState<Category[]>([]);
  const [featuredLots, setFeaturedLots] = useState<Lot[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Load categories
      const { data: categoriesData } = await supabase
        .from('categories')
        .select('*')
        .order('order');

      if (categoriesData) {
        setGames(categoriesData.filter((c: Category) => c.type === 'game'));
        setApps(categoriesData.filter((c: Category) => c.type === 'app'));
        setMobileGames(categoriesData.filter((c: Category) => c.type === 'service'));
      }

      // Load featured lots
      const { data: lotsData } = await supabase
        .from('lots')
        .select('*, seller:profiles(*), category:categories(*)')
        .eq('status', 'active')
        .limit(8)
        .order('created_at', { ascending: false });

      if (lotsData) {
        setFeaturedLots(lotsData as Lot[]);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Demo Mode Banner */}
        {!isSupabaseConfigured && (
          <Alert className="mb-6 border-orange-500 bg-orange-50 dark:bg-orange-900/20">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800 dark:text-orange-200">
              <strong>Демо-режим:</strong> Supabase не настроен. Данные загружены из моков. 
              Для полноценной работы настройте переменные окружения VITE_SUPABASE_URL и VITE_SUPABASE_ANON_KEY.
            </AlertDescription>
          </Alert>
        )}
        
        {/* Hero Section */}
        <section className="mb-12">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/20 via-primary/10 to-background border p-8 md:p-12">
            <div className="relative z-10 max-w-2xl">
              <h1 className="text-3xl md:text-5xl font-bold mb-4">
                Маркетплейс игровых товаров
              </h1>
              <p className="text-lg text-muted-foreground mb-6">
                Покупайте и продавайте игровые товары, аккаунты, валюту и услуги безопасно
              </p>
              <div className="flex flex-wrap gap-3">
                <Button size="lg" asChild>
                  <Link to="/games">Начать покупки</Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link to="/sell">Стать продавцом</Link>
                </Button>
              </div>
            </div>
            <div className="absolute right-0 top-0 w-1/3 h-full opacity-10 hidden md:block">
              <Gamepad2 className="w-full h-full" />
            </div>
          </div>
        </section>

        {/* Plugin Link Banner */}
        <section className="mb-12">
          <a
            href="https://t.me/lovely_market1"
            target="_blank"
            rel="noopener noreferrer"
            className="block"
          >
            <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white transition-transform hover:scale-[1.01]">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold mb-2">Купить плагины FPC можно тут</h2>
                  <p className="text-white/80">Перейти в Telegram канал @lovely_market1</p>
                </div>
                <ExternalLink className="h-8 w-8" />
              </div>
            </div>
          </a>
        </section>

        {/* Games Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Gamepad2 className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold">Популярные игры</h2>
              <Badge variant="secondary">{games.length}</Badge>
            </div>
            <Button variant="ghost" asChild>
              <Link to="/games" className="flex items-center gap-1">
                Все игры
                <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {games.slice(0, 8).map((game) => (
                <CategoryCard key={game.id} category={game} />
              ))}
            </div>
          )}
        </section>

        {/* Apps Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <MessageCircle className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold">Приложения и услуги</h2>
              <Badge variant="secondary">{apps.length}</Badge>
            </div>
            <Button variant="ghost" asChild>
              <Link to="/apps" className="flex items-center gap-1">
                Все приложения
                <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {apps.slice(0, 8).map((app) => (
                <CategoryCard key={app.id} category={app} />
              ))}
            </div>
          )}
        </section>

        {/* Mobile Games Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Smartphone className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold">Мобильные игры</h2>
              <Badge variant="secondary">{mobileGames.length}</Badge>
            </div>
            <Button variant="ghost" asChild>
              <Link to="/mobile-games" className="flex items-center gap-1">
                Все игры
                <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {mobileGames.slice(0, 8).map((game) => (
                <CategoryCard key={game.id} category={game} />
              ))}
            </div>
          )}
        </section>

        {/* Featured Lots & Top Sellers */}
        <section className="mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Featured Lots */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Новые лоты</h2>
                <Button variant="ghost" asChild>
                  <Link to="/lots" className="flex items-center gap-1">
                    Все лоты
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
              
              {loading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[1, 2, 3, 4].map((i) => (
                    <Skeleton key={i} className="h-64 rounded-xl" />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {featuredLots.map((lot) => (
                    <LotCard key={lot.id} lot={lot} />
                  ))}
                </div>
              )}
            </div>

            {/* Top Sellers */}
            <div>
              <TopSellers />
            </div>
          </div>
        </section>

        {/* Support Section */}
        <section className="mb-12">
          <div className="rounded-xl border bg-card p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold mb-2">Нужна помощь?</h3>
                <p className="text-muted-foreground">
                  Наша поддержка всегда готова помочь вам с любыми вопросами
                </p>
              </div>
              <Button asChild>
                <a
                  href="https://t.me/LovelyConfig"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  Написать в поддержку
                </a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/50">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">GM</span>
                </div>
                <span className="font-bold text-xl">GameMarket</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Безопасный маркетплейс для покупки и продажи игровых товаров
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Покупателям</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/games" className="hover:text-primary">Каталог игр</Link></li>
                <li><Link to="/lots" className="hover:text-primary">Все лоты</Link></li>
                <li><Link to="/top-sellers" className="hover:text-primary">Топ продавцов</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Продавцам</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/sell" className="hover:text-primary">Создать лот</Link></li>
                <li><Link to="/finances" className="hover:text-primary">Финансы</Link></li>
                <li><Link to="/rules" className="hover:text-primary">Правила</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Поддержка</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="https://t.me/LovelyConfig" target="_blank" rel="noopener noreferrer" className="hover:text-primary">
                    Telegram поддержка
                  </a>
                </li>
                <li>
                  <a href="https://t.me/lovely_market1" target="_blank" rel="noopener noreferrer" className="hover:text-primary">
                    Плагины FPC
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
            © 2025 GameMarket. Все права защищены.
          </div>
        </div>
      </footer>
    </div>
  );
}
