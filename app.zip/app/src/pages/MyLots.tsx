import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Package,
  Plus,
  Edit,
  Trash2,
  Eye,
  CheckCircle,
  XCircle,
  Archive,
} from 'lucide-react';
import type { Lot } from '@/types';

export function MyLots() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [lots, setLots] = useState<Lot[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [lotToDelete, setLotToDelete] = useState<Lot | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    loadLots();
  }, [user]);

  const loadLots = async () => {
    if (!user) return;

    try {
      const { data } = await supabase
        .from('lots')
        .select('*, category:categories(*), subcategory:subcategories(*)')
        .eq('seller_id', user.id)
        .order('created_at', { ascending: false });

      if (data) {
        setLots(data);
      }
    } catch (error) {
      console.error('Error loading lots:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!lotToDelete) return;

    try {
      const { error } = await supabase
        .from('lots')
        .delete()
        .eq('id', lotToDelete.id);

      if (!error) {
        setLots(lots.filter((l) => l.id !== lotToDelete.id));
        setDeleteDialogOpen(false);
        setLotToDelete(null);
      }
    } catch (error) {
      console.error('Error deleting lot:', error);
      alert('Ошибка при удалении лота');
    }
  };

  const handleStatusChange = async (lotId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('lots')
        .update({ status: newStatus })
        .eq('id', lotId);

      if (!error) {
        loadLots();
      }
    } catch (error) {
      console.error('Error updating lot status:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500">Активен</Badge>;
      case 'sold':
        return <Badge variant="secondary">Продан</Badge>;
      case 'archived':
        return <Badge variant="outline">В архиве</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const activeLots = lots.filter((l) => l.status === 'active');
  const soldLots = lots.filter((l) => l.status === 'sold');
  const archivedLots = lots.filter((l) => l.status === 'archived');

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Требуется авторизация</h1>
          <Button onClick={() => navigate('/auth')}>Войти</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Мои лоты</h1>
          <Button asChild>
            <Link to="/sell">
              <Plus className="mr-2 h-4 w-4" />
              Создать лот
            </Link>
          </Button>
        </div>

        <Tabs defaultValue="active">
          <TabsList className="mb-6">
            <TabsTrigger value="active">
              Активные
              <Badge variant="secondary" className="ml-2">
                {activeLots.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="sold">
              Проданные
              <Badge variant="secondary" className="ml-2">
                {soldLots.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="archived">
              Архив
              <Badge variant="secondary" className="ml-2">
                {archivedLots.length}
              </Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active">
            <LotsList
              lots={activeLots}
              loading={loading}
              onDelete={(lot) => {
                setLotToDelete(lot);
                setDeleteDialogOpen(true);
              }}
              onArchive={(lotId) => handleStatusChange(lotId, 'archived')}
            />
          </TabsContent>

          <TabsContent value="sold">
            <LotsList
              lots={soldLots}
              loading={loading}
              onDelete={(lot) => {
                setLotToDelete(lot);
                setDeleteDialogOpen(true);
              }}
            />
          </TabsContent>

          <TabsContent value="archived">
            <LotsList
              lots={archivedLots}
              loading={loading}
              onDelete={(lot) => {
                setLotToDelete(lot);
                setDeleteDialogOpen(true);
              }}
              onActivate={(lotId) => handleStatusChange(lotId, 'active')}
            />
          </TabsContent>
        </Tabs>
      </main>

      {/* Delete Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Удалить лот?</DialogTitle>
            <DialogDescription>
              Это действие нельзя отменить. Лот будет удален навсегда.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Отмена
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              <Trash2 className="mr-2 h-4 w-4" />
              Удалить
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface LotsListProps {
  lots: Lot[];
  loading: boolean;
  onDelete?: (lot: Lot) => void;
  onArchive?: (lotId: string) => void;
  onActivate?: (lotId: string) => void;
}

function LotsList({ lots, loading, onDelete, onArchive, onActivate }: LotsListProps) {
  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 rounded-xl" />
        ))}
      </div>
    );
  }

  if (lots.length === 0) {
    return (
      <div className="text-center py-16">
        <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-lg font-semibold mb-2">Нет лотов</h3>
        <p className="text-muted-foreground">В этой категории пока нет лотов</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {lots.map((lot) => (
        <Card key={lot.id}>
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              {/* Image */}
              <div className="w-full sm:w-32 h-24 rounded-lg overflow-hidden bg-muted shrink-0">
                {lot.images && lot.images.length > 0 ? (
                  <img
                    src={lot.images[0]}
                    alt={lot.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Package className="h-8 w-8 text-muted-foreground" />
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-semibold truncate">{lot.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {lot.category?.name}
                      {lot.subcategory && ` • ${lot.subcategory.name}`}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-bold text-lg">
                      {lot.price.toLocaleString('ru-RU')} ₽
                    </div>
                    <div className="mt-1">
                      {lot.status === 'active' && (
                        <Badge className="bg-green-500">Активен</Badge>
                      )}
                      {lot.status === 'sold' && (
                        <Badge variant="secondary">Продан</Badge>
                      )}
                      {lot.status === 'archived' && (
                        <Badge variant="outline">В архиве</Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-2 mt-4">
                  <Button variant="outline" size="sm" asChild>
                    <Link to={`/lot/${lot.id}`}>
                      <Eye className="mr-2 h-4 w-4" />
                      Просмотр
                    </Link>
                  </Button>
                  {lot.status === 'active' && (
                    <>
                      <Button variant="outline" size="sm" asChild>
                        <Link to={`/edit-lot/${lot.id}`}>
                          <Edit className="mr-2 h-4 w-4" />
                          Редактировать
                        </Link>
                      </Button>
                      {onArchive && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onArchive(lot.id)}
                        >
                          <Archive className="mr-2 h-4 w-4" />
                          В архив
                        </Button>
                      )}
                    </>
                  )}
                  {lot.status === 'archived' && onActivate && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onActivate(lot.id)}
                    >
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Активировать
                    </Button>
                  )}
                  {onDelete && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-600 hover:text-red-700"
                      onClick={() => onDelete(lot)}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Удалить
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
