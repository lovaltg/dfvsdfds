import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase, getOrCreateChat } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  ChevronRight,
  MessageSquare,
  ShoppingCart,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock,
} from 'lucide-react';
import type { Lot as LotType } from '@/types';

export function Lot() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [lot, setLot] = useState<LotType | null>(null);
  const [loading, setLoading] = useState(true);
  const [buyDialogOpen, setBuyDialogOpen] = useState(false);
  const [orderNumber, setOrderNumber] = useState<string>('');
  const [creatingOrder, setCreatingOrder] = useState(false);

  useEffect(() => {
    if (id) {
      loadLot();
    }
  }, [id]);

  const loadLot = async () => {
    try {
      const { data } = await supabase
        .from('lots')
        .select('*, seller:profiles(*), category:categories(*), subcategory:subcategories(*)')
        .eq('id', id)
        .single();

      if (data) {
        setLot(data as LotType);
      }
    } catch (error) {
      console.error('Error loading lot:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBuy = async () => {
    if (!user || !lot) return;

    setCreatingOrder(true);
    try {
      // Generate order number
      const timestamp = Date.now().toString(36).toUpperCase();
      const random = Math.random().toString(36).substring(2, 6).toUpperCase();
      const newOrderNumber = `ORD-${timestamp}-${random}`;
      setOrderNumber(newOrderNumber);

      // Create order
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          order_number: newOrderNumber,
          buyer_id: user.id,
          seller_id: lot.seller_id,
          lot_id: lot.id,
          amount: lot.price,
          status: 'pending',
        })
        .select()
        .single();

      if (orderError) throw orderError;

      // Create transaction for payment
      await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          type: 'payment',
          amount: -lot.price,
          status: 'completed',
          description: `Оплата заказа ${newOrderNumber}`,
          order_id: order.id,
        });

      // Update lot status
      await supabase
        .from('lots')
        .update({ status: 'sold' })
        .eq('id', lot.id);

      setBuyDialogOpen(true);
    } catch (error) {
      console.error('Error creating order:', error);
      alert('Ошибка при создании заказа');
    } finally {
      setCreatingOrder(false);
    }
  };

  const handleChat = async () => {
    if (!user || !lot) {
      navigate('/auth');
      return;
    }

    if (user.id === lot.seller_id) {
      alert('Нельзя написать самому себе');
      return;
    }

    const { data: chat } = await getOrCreateChat(user.id, lot.seller_id);
    if (chat) {
      navigate(`/chats?chat=${chat.id}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Skeleton className="aspect-video rounded-xl mb-6" />
              <Skeleton className="h-8 w-3/4 mb-4" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-2/3" />
            </div>
            <div>
              <Skeleton className="h-64 rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!lot) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Лот не найден</h1>
          <p className="text-muted-foreground mb-6">
            Запрашиваемый лот не существует или был удален
          </p>
          <Button asChild>
            <Link to="/">Вернуться на главную</Link>
          </Button>
        </div>
      </div>
    );
  }

  const isOwner = user?.id === lot.seller_id;
  const discount = lot.old_price
    ? Math.round(((lot.old_price - lot.price) / lot.old_price) * 100)
    : null;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link to="/" className="hover:text-primary">Главная</Link>
          <ChevronRight className="h-4 w-4" />
          {lot.category && (
            <>
              <Link to={`/category/${lot.category.slug}`} className="hover:text-primary">
                {lot.category.name}
              </Link>
              <ChevronRight className="h-4 w-4" />
            </>
          )}
          <span className="text-foreground truncate max-w-xs">{lot.title}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Images & Description */}
          <div className="lg:col-span-2 space-y-6">
            {/* Images */}
            <div className="relative aspect-video overflow-hidden rounded-xl border bg-card">
              {lot.images && lot.images.length > 0 ? (
                <img
                  src={lot.images[0]}
                  alt={lot.title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
                  <span className="text-6xl font-bold text-primary/30">
                    {lot.title.charAt(0)}
                  </span>
                </div>
              )}
              {discount && discount > 0 && (
                <Badge className="absolute top-4 right-4 bg-red-500 text-white text-lg px-3 py-1">
                  -{discount}%
                </Badge>
              )}
            </div>

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>Описание</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="whitespace-pre-wrap">{lot.description}</p>
              </CardContent>
            </Card>

            {/* Seller Info */}
            <Card>
              <CardHeader>
                <CardTitle>Продавец</CardTitle>
              </CardHeader>
              <CardContent>
                <Link
                  to={`/profile/${lot.seller_id}`}
                  className="flex items-center gap-4 p-4 rounded-lg hover:bg-muted transition-colors"
                >
                  {lot.seller?.avatar_url ? (
                    <img
                      src={lot.seller.avatar_url}
                      alt={lot.seller.username}
                      className="h-16 w-16 rounded-full object-cover"
                    />
                  ) : (
                    <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-2xl font-bold text-primary">
                        {lot.seller?.username?.charAt(0) || '?'}
                      </span>
                    </div>
                  )}
                  <div>
                    <div className="font-semibold text-lg">{lot.seller?.username}</div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      На сайте с {new Date(lot.seller?.created_at || '').toLocaleDateString('ru-RU')}
                    </div>
                  </div>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Price & Actions */}
          <div className="space-y-6">
            <Card className="sticky top-24">
              <CardContent className="p-6 space-y-6">
                {/* Title */}
                <h1 className="text-xl font-bold">{lot.title}</h1>

                {/* Price */}
                <div>
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400">
                    {lot.price.toLocaleString('ru-RU')} ₽
                  </div>
                  {lot.old_price && (
                    <div className="text-lg text-muted-foreground line-through">
                      {lot.old_price.toLocaleString('ru-RU')} ₽
                    </div>
                  )}
                </div>

                <Separator />

                {/* Info */}
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Гарантия сделки</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-blue-500" />
                    <span>Моментальная доставка</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 text-orange-500" />
                    <span>В наличии: {lot.quantity} шт.</span>
                  </div>
                </div>

                <Separator />

                {/* Actions */}
                <div className="space-y-3">
                  {!isOwner ? (
                    <>
                      <Button
                        className="w-full bg-green-600 hover:bg-green-700 text-white h-12 text-lg"
                        onClick={() => {
                          if (!user) {
                            navigate('/auth');
                            return;
                          }
                          setBuyDialogOpen(true);
                        }}
                        disabled={creatingOrder}
                      >
                        <ShoppingCart className="mr-2 h-5 w-5" />
                        {creatingOrder ? 'Создание заказа...' : 'Купить'}
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full h-12"
                        onClick={handleChat}
                      >
                        <MessageSquare className="mr-2 h-5 w-5" />
                        Написать продавцу
                      </Button>
                    </>
                  ) : (
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <p className="text-muted-foreground">Это ваш лот</p>
                      <Button
                        variant="outline"
                        className="mt-2"
                        onClick={() => navigate('/my-lots')}
                      >
                        Управление лотами
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Buy Dialog */}
      <Dialog open={buyDialogOpen} onOpenChange={setBuyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Подтверждение покупки</DialogTitle>
            <DialogDescription>
              Вы собираетесь купить: {lot.title}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex justify-between items-center p-4 bg-muted rounded-lg">
              <span>Сумма к оплате:</span>
              <span className="text-xl font-bold">{lot.price.toLocaleString('ru-RU')} ₽</span>
            </div>
            {orderNumber && (
              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="flex items-center gap-2 text-green-600 dark:text-green-400 mb-2">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-semibold">Заказ создан!</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Номер заказа: <span className="font-mono font-bold">{orderNumber}</span>
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Сохраните этот номер для отслеживания заказа
                </p>
              </div>
            )}
            <div className="flex gap-3">
              {!orderNumber ? (
                <>
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setBuyDialogOpen(false)}
                  >
                    Отмена
                  </Button>
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={handleBuy}
                    disabled={creatingOrder}
                  >
                    {creatingOrder ? 'Обработка...' : 'Подтвердить'}
                  </Button>
                </>
              ) : (
                <Button
                  className="w-full"
                  onClick={() => navigate('/orders')}
                >
                  Перейти к заказам
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
