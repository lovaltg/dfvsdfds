import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  ShoppingCart,
  RotateCcw,
  CreditCard,
  Banknote,
  Bitcoin,
  CheckCircle,
} from 'lucide-react';
import type { Transaction } from '@/types';

export function Finances() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [depositDialogOpen, setDepositDialogOpen] = useState(false);
  const [withdrawDialogOpen, setWithdrawDialogOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState('card');
  const [withdrawDetails, setWithdrawDetails] = useState('');
  const [processing, setProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (user) {
      loadTransactions();
    }
  }, [user]);

  const loadTransactions = async () => {
    if (!user) return;

    try {
      const { data } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (data) {
        setTransactions(data as Transaction[]);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeposit = async () => {
    if (!user || !depositAmount) return;

    setProcessing(true);
    try {
      const amount = parseFloat(depositAmount);
      if (isNaN(amount) || amount <= 0) {
        alert('Введите корректную сумму');
        return;
      }

      // Create deposit transaction
      const { error } = await supabase.from('transactions').insert({
        user_id: user.id,
        type: 'deposit',
        amount: amount,
        status: 'pending',
        payment_method: 'card',
        description: 'Пополнение баланса',
      });

      if (error) throw error;

      setSuccessMessage(`Запрос на пополнение на ${amount} ₽ создан`);
      setDepositDialogOpen(false);
      setDepositAmount('');
      loadTransactions();
    } catch (error) {
      console.error('Error creating deposit:', error);
      alert('Ошибка при создании запроса на пополнение');
    } finally {
      setProcessing(false);
    }
  };

  const handleWithdraw = async () => {
    if (!user || !withdrawAmount || !withdrawDetails) return;

    setProcessing(true);
    try {
      const amount = parseFloat(withdrawAmount);
      if (isNaN(amount) || amount <= 0) {
        alert('Введите корректную сумму');
        return;
      }

      if (profile && profile.balance < amount) {
        alert('Недостаточно средств на балансе');
        return;
      }

      // Create withdrawal transaction
      const { error } = await supabase.from('transactions').insert({
        user_id: user.id,
        type: 'withdrawal',
        amount: -amount,
        status: 'pending',
        payment_method: withdrawMethod,
        description: `Вывод на ${withdrawMethod}: ${withdrawDetails}`,
      });

      if (error) throw error;

      setSuccessMessage(`Запрос на вывод ${amount} ₽ создан`);
      setWithdrawDialogOpen(false);
      setWithdrawAmount('');
      setWithdrawDetails('');
      loadTransactions();
    } catch (error) {
      console.error('Error creating withdrawal:', error);
      alert('Ошибка при создании запроса на вывод');
    } finally {
      setProcessing(false);
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownLeft className="h-5 w-5 text-green-500" />;
      case 'withdrawal':
        return <ArrowUpRight className="h-5 w-5 text-red-500" />;
      case 'payment':
        return <ShoppingCart className="h-5 w-5 text-blue-500" />;
      case 'refund':
        return <RotateCcw className="h-5 w-5 text-orange-500" />;
      default:
        return <Wallet className="h-5 w-5" />;
    }
  };

  const getTransactionTypeLabel = (type: string) => {
    switch (type) {
      case 'deposit':
        return 'Пополнение';
      case 'withdrawal':
        return 'Вывод';
      case 'payment':
        return 'Оплата';
      case 'refund':
        return 'Возврат';
      default:
        return type;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500">Выполнено</Badge>;
      case 'pending':
        return <Badge variant="secondary">В обработке</Badge>;
      case 'failed':
        return <Badge variant="destructive">Ошибка</Badge>;
      case 'cancelled':
        return <Badge variant="outline">Отменено</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Требуется авторизация</h1>
          <p className="text-muted-foreground mb-6">
            Войдите в аккаунт, чтобы управлять финансами
          </p>
          <Button onClick={() => navigate('/auth')}>Войти</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Финансы</h1>

        {/* Balance Card */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="p-4 bg-primary/10 rounded-full">
                  <Wallet className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <p className="text-muted-foreground">Текущий баланс</p>
                  <p className="text-4xl font-bold">
                    {profile?.balance?.toLocaleString('ru-RU') || '0'} ₽
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setDepositDialogOpen(true)}
                >
                  <ArrowDownLeft className="mr-2 h-4 w-4" />
                  Пополнить
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setWithdrawDialogOpen(true)}
                >
                  <ArrowUpRight className="mr-2 h-4 w-4" />
                  Вывести
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Success Message */}
        {successMessage && (
          <div className="mb-6 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg flex items-center gap-2 text-green-600 dark:text-green-400">
            <CheckCircle className="h-5 w-5" />
            {successMessage}
          </div>
        )}

        {/* Transactions */}
        <Card>
          <CardHeader>
            <CardTitle>История операций</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 rounded-lg" />
                ))}
              </div>
            ) : transactions.length > 0 ? (
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-muted rounded-full">
                        {getTransactionIcon(transaction.type)}
                      </div>
                      <div>
                        <div className="font-medium">
                          {getTransactionTypeLabel(transaction.type)}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {transaction.description || 'Без описания'}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(transaction.created_at).toLocaleString('ru-RU')}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={`font-bold text-lg ${
                          transaction.amount > 0 ? 'text-green-600' : 'text-red-600'
                        }`}
                      >
                        {transaction.amount > 0 ? '+' : ''}
                        {transaction.amount.toLocaleString('ru-RU')} ₽
                      </div>
                      <div className="mt-1">{getStatusBadge(transaction.status)}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Wallet className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">Нет операций</h3>
                <p className="text-muted-foreground">
                  История операций будет отображаться здесь
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Deposit Dialog */}
      <Dialog open={depositDialogOpen} onOpenChange={setDepositDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Пополнение баланса</DialogTitle>
            <DialogDescription>
              Введите сумму для пополнения баланса
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="deposit-amount">Сумма (₽)</Label>
              <Input
                id="deposit-amount"
                type="number"
                min="1"
                placeholder="1000"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
              />
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">
                Инструкция по пополнению:
              </p>
              <ol className="text-sm space-y-1 list-decimal list-inside">
                <li>Введите сумму пополнения</li>
                <li>Нажмите "Пополнить"</li>
                <li>Следуйте инструкциям платежной системы</li>
              </ol>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setDepositDialogOpen(false)}
              >
                Отмена
              </Button>
              <Button
                className="flex-1"
                onClick={handleDeposit}
                disabled={processing || !depositAmount}
              >
                {processing ? 'Обработка...' : 'Пополнить'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Withdraw Dialog */}
      <Dialog open={withdrawDialogOpen} onOpenChange={setWithdrawDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Вывод средств</DialogTitle>
            <DialogDescription>
              Введите сумму и способ вывода
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="withdraw-amount">Сумма (₽)</Label>
              <Input
                id="withdraw-amount"
                type="number"
                min="1"
                placeholder="1000"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Доступно: {profile?.balance?.toLocaleString('ru-RU') || '0'} ₽
              </p>
            </div>
            <div className="space-y-2">
              <Label>Способ вывода</Label>
              <Select value={withdrawMethod} onValueChange={setWithdrawMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="card">
                    <div className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4" />
                      Банковская карта
                    </div>
                  </SelectItem>
                  <SelectItem value="sbp">
                    <div className="flex items-center gap-2">
                      <Banknote className="h-4 w-4" />
                      СБП
                    </div>
                  </SelectItem>
                  <SelectItem value="crypto">
                    <div className="flex items-center gap-2">
                      <Bitcoin className="h-4 w-4" />
                      Криптовалюта
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="withdraw-details">Реквизиты</Label>
              <Input
                id="withdraw-details"
                placeholder={
                  withdrawMethod === 'card'
                    ? 'Номер карты'
                    : withdrawMethod === 'sbp'
                    ? 'Номер телефона'
                    : 'Адрес кошелька'
                }
                value={withdrawDetails}
                onChange={(e) => setWithdrawDetails(e.target.value)}
              />
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setWithdrawDialogOpen(false)}
              >
                Отмена
              </Button>
              <Button
                className="flex-1"
                onClick={handleWithdraw}
                disabled={processing || !withdrawAmount || !withdrawDetails}
              >
                {processing ? 'Обработка...' : 'Вывести'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
