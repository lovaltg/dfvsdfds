import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Calendar,
  User,
  Package,
  Star,
  MessageSquare,
  Edit,
  CheckCircle,
  XCircle,
  Clock,
  Camera,
} from 'lucide-react';
import type { Profile as ProfileType, Lot, Review } from '@/types';

export function Profile() {
  const { id } = useParams<{ id: string }>();
  const { user, profile: currentProfile } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<ProfileType | null>(null);
  const [lots, setLots] = useState<Lot[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({ username: '', avatar_url: '' });
  const [uploading, setUploading] = useState(false);

  const isOwner = user?.id === id;

  useEffect(() => {
    if (id) {
      loadProfileData();
    }
  }, [id]);

  const loadProfileData = async () => {
    try {
      setLoading(true);
      
      // Load profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', id)
        .single();

      if (profileData) {
        setProfile(profileData);
        setEditForm({
          username: profileData.username,
          avatar_url: profileData.avatar_url || '',
        });

        // Load lots
        const { data: lotsData } = await supabase
          .from('lots')
          .select('*, category:categories(*), subcategory:subcategories(*)')
          .eq('seller_id', id)
          .eq('status', 'active')
          .order('created_at', { ascending: false });

        setLots(lotsData || []);

        // Load reviews
        const { data: reviewsData } = await supabase
          .from('reviews')
          .select('*, reviewer:profiles(*)')
          .eq('reviewed_id', id)
          .order('created_at', { ascending: false });

        setReviews(reviewsData || []);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!profile) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          username: editForm.username,
          avatar_url: editForm.avatar_url,
          nickname_changed_at: new Date().toISOString(),
        })
        .eq('id', profile.id);

      if (!error) {
        setIsEditing(false);
        loadProfileData();
      }
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;

    // Check file size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('Файл слишком большой. Максимальный размер: 10MB');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${profile.id}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);

      setEditForm({ ...editForm, avatar_url: publicUrl });
    } catch (error) {
      console.error('Error uploading avatar:', error);
      alert('Ошибка при загрузке аватарки');
    } finally {
      setUploading(false);
    }
  };

  const canChangeNickname = () => {
    if (!profile?.nickname_changed_at) return true;
    const lastChange = new Date(profile.nickname_changed_at);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - lastChange.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays >= 14;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-6 mb-8">
            <Skeleton className="h-24 w-24 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
          <Skeleton className="h-96 rounded-xl" />
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Профиль не найден</h1>
          <p className="text-muted-foreground mb-6">
            Запрашиваемый профиль не существует или был удален
          </p>
          <Button asChild>
            <Link to="/">Вернуться на главную</Link>
          </Button>
        </div>
      </div>
    );
  }

  const isOnline = new Date(profile.last_online).getTime() > Date.now() - 5 * 60 * 1000;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center gap-6 mb-8">
          <div className="relative">
            {profile.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt={profile.username}
                className="h-24 w-24 rounded-full object-cover border-4 border-background shadow-lg"
              />
            ) : (
              <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center border-4 border-background shadow-lg">
                <span className="text-3xl font-bold text-primary">
                  {profile.username.charAt(0).toUpperCase()}
                </span>
              </div>
            )}
            <div
              className={`absolute bottom-1 right-1 w-5 h-5 rounded-full border-2 border-background ${
                isOnline ? 'bg-green-500' : 'bg-gray-400'
              }`}
            />
          </div>
          
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold">{profile.username}</h1>
              <Badge variant={isOnline ? 'default' : 'secondary'}>
                {isOnline ? 'Онлайн' : 'Офлайн'}
              </Badge>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                На сайте с {new Date(profile.created_at).toLocaleDateString('ru-RU')}
              </span>
              <span className="flex items-center gap-1">
                <Package className="h-4 w-4" />
                {lots.length} {lots.length === 1 ? 'лот' : lots.length < 5 ? 'лота' : 'лотов'}
              </span>
              <span className="flex items-center gap-1">
                <Star className="h-4 w-4" />
                {reviews.length} отзывов
              </span>
            </div>
          </div>

          {isOwner && (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="mr-2 h-4 w-4" />
              Редактировать
            </Button>
          )}

          {!isOwner && user && (
            <Button
              variant="outline"
              onClick={() => navigate(`/chats?user=${profile.id}`)}
            >
              <MessageSquare className="mr-2 h-4 w-4" />
              Написать
            </Button>
          )}
        </div>

        <Tabs defaultValue="lots" className="space-y-6">
          <TabsList>
            <TabsTrigger value="lots">
              <Package className="mr-2 h-4 w-4" />
              Лоты
            </TabsTrigger>
            <TabsTrigger value="reviews">
              <Star className="mr-2 h-4 w-4" />
              Отзывы
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lots">
            {lots.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {lots.map((lot) => (
                  <Link
                    key={lot.id}
                    to={`/lot/${lot.id}`}
                    className="group relative overflow-hidden rounded-xl border bg-card p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                  >
                    <div className="relative aspect-video overflow-hidden rounded-lg mb-4">
                      {lot.images && lot.images.length > 0 ? (
                        <img
                          src={lot.images[0]}
                          alt={lot.title}
                          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-primary/5">
                          <span className="text-2xl font-bold text-primary/30">
                            {lot.title.charAt(0)}
                          </span>
                        </div>
                      )}
                    </div>
                    <h3 className="font-semibold line-clamp-2 mb-2">{lot.title}</h3>
                    <div className="text-lg font-bold text-green-600 dark:text-green-400">
                      {lot.price.toLocaleString('ru-RU')} ₽
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="text-6xl mb-4">📦</div>
                <h3 className="text-xl font-semibold mb-2">Нет активных лотов</h3>
                {isOwner && (
                  <Button className="mt-4" asChild>
                    <Link to="/sell">Создать лот</Link>
                  </Button>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="reviews">
            {reviews.length > 0 ? (
              <div className="space-y-4">
                {reviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        {review.reviewer?.avatar_url ? (
                          <img
                            src={review.reviewer.avatar_url}
                            alt={review.reviewer.username}
                            className="h-10 w-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-sm font-bold text-primary">
                              {review.reviewer?.username?.charAt(0) || '?'}
                            </span>
                          </div>
                        )}
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="font-semibold">
                              {review.reviewer?.username}
                            </span>
                            <div className="flex items-center gap-1">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < review.rating
                                      ? 'fill-yellow-400 text-yellow-400'
                                      : 'text-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <p className="text-muted-foreground">{review.comment}</p>
                          <span className="text-xs text-muted-foreground mt-2 block">
                            {new Date(review.created_at).toLocaleDateString('ru-RU')}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="text-6xl mb-4">⭐</div>
                <h3 className="text-xl font-semibold mb-2">Нет отзывов</h3>
                <p className="text-muted-foreground">
                  У этого пользователя пока нет отзывов
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* Edit Profile Dialog */}
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Редактировать профиль</DialogTitle>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* Avatar */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                {editForm.avatar_url ? (
                  <img
                    src={editForm.avatar_url}
                    alt="Avatar"
                    className="h-24 w-24 rounded-full object-cover"
                  />
                ) : (
                  <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-10 w-10 text-primary" />
                  </div>
                )}
                <label className="absolute bottom-0 right-0 p-2 bg-primary text-white rounded-full cursor-pointer hover:bg-primary/90 transition-colors">
                  <Camera className="h-4 w-4" />
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleAvatarUpload}
                    disabled={uploading}
                  />
                </label>
              </div>
              {uploading && <span className="text-sm text-muted-foreground">Загрузка...</span>}
            </div>

            {/* Username */}
            <div className="space-y-2">
              <Label htmlFor="username">Никнейм</Label>
              <Input
                id="username"
                value={editForm.username}
                onChange={(e) => setEditForm({ ...editForm, username: e.target.value })}
                disabled={!canChangeNickname()}
              />
              {!canChangeNickname() && (
                <p className="text-sm text-orange-500">
                  Никнейм можно менять раз в 14 дней
                </p>
              )}
            </div>

            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setIsEditing(false)}>
                Отмена
              </Button>
              <Button className="flex-1" onClick={handleSaveProfile}>
                Сохранить
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
