import { createClient } from '@supabase/supabase-js';

// ============================================
// ВСТАВЬТЕ СВОИ КЛЮЧИ SUPABASE ЗДЕСЬ
// ============================================
// Замените пустые строки на ваши реальные ключи:
const HARDCODED_SUPABASE_URL = ''; // например: 'https://abcdef123456.supabase.co'
const HARDCODED_SUPABASE_ANON_KEY = ''; // например: 'eyJhbGciOiJIUzI1NiIs...'
// ============================================

// Пробуем получить из .env, если нет - используем жёстко прописанные
const envUrl = import.meta.env.VITE_SUPABASE_URL || '';
const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

const supabaseUrl = HARDCODED_SUPABASE_URL || envUrl;
const supabaseAnonKey = HARDCODED_SUPABASE_ANON_KEY || envKey;

// Debug logging
console.log('=== SUPABASE CONFIG ===');
console.log('URL exists:', !!supabaseUrl);
console.log('URL value:', supabaseUrl?.substring(0, 30) + '...');
console.log('Key exists:', !!supabaseAnonKey);
console.log('Key length:', supabaseAnonKey?.length);
console.log('=======================');

// Check if Supabase is configured
export const isSupabaseConfigured = !!(supabaseUrl && supabaseAnonKey);

// Create client only if configured, otherwise create a mock
export const supabase = isSupabaseConfigured 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : createMockSupabase();

if (isSupabaseConfigured) {
  console.log('✅ Using REAL Supabase connection');
} else {
  console.log('⚠️ Using MOCK Supabase (DEMO MODE)');
}

// Mock Supabase for demo mode
function createMockSupabase() {
  console.log('Running in DEMO MODE - Supabase not configured');
  
  return {
    auth: {
      getSession: () => Promise.resolve({ data: { session: null }, error: null }),
      getUser: () => Promise.resolve({ data: { user: null }, error: null }),
      signInWithOAuth: () => Promise.resolve({ data: null, error: new Error('Demo mode - auth not available') }),
      signInWithPassword: () => Promise.resolve({ data: null, error: new Error('Demo mode - auth not available') }),
      signUp: () => Promise.resolve({ data: null, error: new Error('Demo mode - auth not available') }),
      signOut: () => Promise.resolve({ error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
    },
    from: (table: string) => createMockTable(table),
    storage: {
      from: () => ({
        upload: () => Promise.resolve({ error: null }),
        getPublicUrl: () => ({ data: { publicUrl: '' } }),
      }),
    },
    channel: () => ({
      on: () => ({ subscribe: () => ({ unsubscribe: () => {} }) }),
    }),
  } as any;
}

// Mock table data
const mockData: Record<string, any[]> = {
  categories: [
    { id: '1', name: 'Rust', slug: 'rust', type: 'game', icon: null, parent_id: null, order: 1, image_url: null, is_new: false },
    { id: '2', name: 'CS2', slug: 'cs2', type: 'game', icon: null, parent_id: null, order: 2, image_url: null, is_new: false },
    { id: '3', name: 'Dota 2', slug: 'dota-2', type: 'game', icon: null, parent_id: null, order: 3, image_url: null, is_new: false },
    { id: '4', name: 'Valorant', slug: 'valorant', type: 'game', icon: null, parent_id: null, order: 4, image_url: null, is_new: true },
    { id: '5', name: 'Telegram', slug: 'telegram', type: 'app', icon: null, parent_id: null, order: 5, image_url: null, is_new: false },
    { id: '6', name: 'Steam', slug: 'steam', type: 'app', icon: null, parent_id: null, order: 6, image_url: null, is_new: false },
    { id: '7', name: 'Brawl Stars', slug: 'brawl-stars', type: 'service', icon: null, parent_id: null, order: 7, image_url: null, is_new: true },
    { id: '8', name: 'PUBG Mobile', slug: 'pubg-mobile', type: 'service', icon: null, parent_id: null, order: 8, image_url: null, is_new: false },
  ],
  lots: [
    { 
      id: '1', 
      seller_id: 'seller1', 
      category_id: '1', 
      subcategory_id: null,
      title: '1000 серебряных осколков Rust', 
      description: 'Быстрая доставка серебряных осколков для Rust. Безопасная сделка.', 
      price: 500, 
      old_price: 650, 
      quantity: 100, 
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      images: [],
      seller: { id: 'seller1', username: 'pedalick', avatar_url: null, created_at: new Date().toISOString() },
      category: { id: '1', name: 'Rust', slug: 'rust' }
    },
    { 
      id: '2', 
      seller_id: 'seller2', 
      category_id: '1', 
      subcategory_id: null,
      title: 'VIP статус Rust', 
      description: 'VIP статус на сервере Rust. Премиум привилегии.', 
      price: 1200, 
      old_price: null, 
      quantity: 50, 
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      images: [],
      seller: { id: 'seller2', username: 'lovely', avatar_url: null, created_at: new Date().toISOString() },
      category: { id: '1', name: 'Rust', slug: 'rust' }
    },
    { 
      id: '3', 
      seller_id: 'seller3', 
      category_id: '2', 
      subcategory_id: null,
      title: 'Скины CS2 - AK-47 | Красная линия', 
      description: 'Редкий скин для AK-47 в CS2. Состояние: Прямо с завода.', 
      price: 3500, 
      old_price: 4200, 
      quantity: 5, 
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      images: [],
      seller: { id: 'seller3', username: 'ghoosefun', avatar_url: null, created_at: new Date().toISOString() },
      category: { id: '2', name: 'CS2', slug: 'cs2' }
    },
    { 
      id: '4', 
      seller_id: 'seller1', 
      category_id: '5', 
      subcategory_id: null,
      title: 'Telegram Premium 3 месяца', 
      description: 'Telegram Premium по юзернейму. Быстрая активация.', 
      price: 1100, 
      old_price: 1300, 
      quantity: 200, 
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      images: [],
      seller: { id: 'seller1', username: 'pedalick', avatar_url: null, created_at: new Date().toISOString() },
      category: { id: '5', name: 'Telegram', slug: 'telegram' }
    },
  ],
  profiles: [
    { id: 'seller1', username: 'pedalick', avatar_url: null, email: 'pedalick@example.com', created_at: new Date().toISOString(), last_online: new Date().toISOString(), nickname_changed_at: null, balance: 15000 },
    { id: 'seller2', username: 'lovely', avatar_url: null, email: 'lovely@example.com', created_at: new Date().toISOString(), last_online: new Date().toISOString(), nickname_changed_at: null, balance: 8500 },
    { id: 'seller3', username: 'ghoosefun', avatar_url: null, email: 'ghoosefun@example.com', created_at: new Date().toISOString(), last_online: new Date().toISOString(), nickname_changed_at: null, balance: 12000 },
  ],
  subcategories: [],
  chats: [],
  messages: [],
  orders: [],
  transactions: [],
  reviews: [],
};

function createMockTable(tableName: string) {
  const data = mockData[tableName] || [];
  
  const chainable = {
    eq: (column: string, value: any) => ({
      single: () => Promise.resolve({ data: data.find((item: any) => item[column] === value) || null, error: null }),
      order: (col?: string, opts?: { ascending?: boolean }) => Promise.resolve({ 
        data: data.filter((item: any) => item[column] === value), 
        error: null 
      }),
      limit: (n: number) => Promise.resolve({ data: data.filter((item: any) => item[column] === value).slice(0, n), error: null }),
    }),
    order: (column: string, opts?: { ascending?: boolean }) => Promise.resolve({ 
      data: [...data].sort((a: any, b: any) => {
        const ascending = opts?.ascending ?? true;
        if (ascending) return a[column] > b[column] ? 1 : -1;
        return a[column] < b[column] ? 1 : -1;
      }), 
      error: null 
    }),
    limit: (n: number) => Promise.resolve({ data: data.slice(0, n), error: null }),
    single: () => Promise.resolve({ data: data[0] || null, error: null }),
  };
  
  return {
    select: (columns?: string) => chainable,
    insert: (values: any) => Promise.resolve({ 
      data: { ...values, id: Math.random().toString(36).substr(2, 9) }, 
      error: null 
    }),
    update: (values: any) => ({
      eq: (column: string, value: any) => Promise.resolve({ data: { ...values }, error: null }),
    }),
    delete: () => ({
      eq: (column: string, value: any) => Promise.resolve({ error: null }),
    }),
  };
}

// Auth helpers
export const signInWithGoogle = async () => {
  if (!isSupabaseConfigured) {
    return { data: null, error: new Error('Demo mode - Google auth not available. Please configure Supabase.') };
  }
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: `${window.location.origin}/auth/callback`,
    },
  });
  return { data, error };
};

export const signInWithEmail = async (email: string, password: string) => {
  if (!isSupabaseConfigured) {
    return { error: new Error('Demo mode - Email auth not available. Please configure Supabase.') };
  }
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signUpWithEmail = async (email: string, password: string) => {
  if (!isSupabaseConfigured) {
    return { error: new Error('Demo mode - Email signup not available. Please configure Supabase.') };
  }
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${window.location.origin}/auth/callback`,
    },
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const getProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();
  return { data, error };
};

export const updateProfile = async (userId: string, updates: any) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .single();
  return { data, error };
};

// Categories
export const getCategories = async () => {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('order');
  return { data, error };
};

export const getCategoryBySlug = async (slug: string) => {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .eq('slug', slug)
    .single();
  return { data, error };
};

export const getSubcategories = async (categoryId: string) => {
  const { data, error } = await supabase
    .from('subcategories')
    .select('*')
    .eq('category_id', categoryId);
  return { data, error };
};

// Lots
export const getLots = async (filters?: { category_id?: string; subcategory_id?: string; seller_id?: string }) => {
  let query = supabase
    .from('lots')
    .select('*, seller:profiles(*), category:categories(*), subcategory:subcategories(*)')
    .eq('status', 'active');
  
  if (filters?.category_id) {
    query = query.eq('category_id', filters.category_id);
  }
  if (filters?.subcategory_id) {
    query = query.eq('subcategory_id', filters.subcategory_id);
  }
  if (filters?.seller_id) {
    query = query.eq('seller_id', filters.seller_id);
  }
  
  const { data, error } = await query.order('created_at', { ascending: false });
  return { data, error };
};

export const getLotById = async (id: string) => {
  const { data, error } = await supabase
    .from('lots')
    .select('*, seller:profiles(*), category:categories(*), subcategory:subcategories(*)')
    .eq('id', id)
    .single();
  return { data, error };
};

export const createLot = async (lot: any) => {
  const { data, error } = await supabase
    .from('lots')
    .insert(lot)
    .select()
    .single();
  return { data, error };
};

export const updateLot = async (id: string, updates: any) => {
  const { data, error } = await supabase
    .from('lots')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  return { data, error };
};

export const deleteLot = async (id: string) => {
  const { error } = await supabase
    .from('lots')
    .delete()
    .eq('id', id);
  return { error };
};

// Orders
export const createOrder = async (order: any) => {
  const { data, error } = await supabase
    .from('orders')
    .insert(order)
    .select()
    .single();
  return { data, error };
};

export const getOrders = async (userId: string, as: 'buyer' | 'seller') => {
  const { data, error } = await supabase
    .from('orders')
    .select('*, buyer:profiles!orders_buyer_id_fkey(*), seller:profiles!orders_seller_id_fkey(*), lot:lots(*)')
    .eq(as === 'buyer' ? 'buyer_id' : 'seller_id', userId)
    .order('created_at', { ascending: false });
  return { data, error };
};

// Transactions
export const getTransactions = async (userId: string) => {
  const { data, error } = await supabase
    .from('transactions')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  return { data, error };
};

export const createTransaction = async (transaction: any) => {
  const { data, error } = await supabase
    .from('transactions')
    .insert(transaction)
    .select()
    .single();
  return { data, error };
};

// Chats
export const getChats = async (userId: string) => {
  const { data, error } = await supabase
    .from('chats')
    .select(`
      *,
      participant_1_profile:profiles!chats_participant_1_fkey(*),
      participant_2_profile:profiles!chats_participant_2_fkey(*)
    `)
    .or(`participant_1.eq.${userId},participant_2.eq.${userId}`)
    .order('last_message_at', { ascending: false });
  return { data, error };
};

export const getOrCreateChat = async (userId1: string, userId2: string) => {
  // Check if chat exists
  const { data: existingChat } = await supabase
    .from('chats')
    .select('*')
    .or(`and(participant_1.eq.${userId1},participant_2.eq.${userId2}),and(participant_1.eq.${userId2},participant_2.eq.${userId1})`)
    .single();
  
  if (existingChat) {
    return { data: existingChat, error: null };
  }
  
  // Create new chat
  const { data, error } = await supabase
    .from('chats')
    .insert({
      participant_1: userId1,
      participant_2: userId2,
    })
    .select()
    .single();
  return { data, error };
};

export const getMessages = async (chatId: string) => {
  const { data, error } = await supabase
    .from('messages')
    .select('*, sender:profiles(*)')
    .eq('chat_id', chatId)
    .order('created_at', { ascending: true });
  return { data, error };
};

export const sendMessage = async (chatId: string, senderId: string, content: string) => {
  const { data, error } = await supabase
    .from('messages')
    .insert({
      chat_id: chatId,
      sender_id: senderId,
      content,
    })
    .select()
    .single();
  
  if (!error) {
    // Update chat last_message_at
    await supabase
      .from('chats')
      .update({ last_message_at: new Date().toISOString() })
      .eq('id', chatId);
  }
  
  return { data, error };
};

// Reviews
export const getReviews = async (userId: string) => {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, reviewer:profiles(*)')
    .eq('reviewed_id', userId)
    .order('created_at', { ascending: false });
  return { data, error };
};

export const createReview = async (review: any) => {
  const { data, error } = await supabase
    .from('reviews')
    .insert(review)
    .select()
    .single();
  return { data, error };
};

// Upload avatar
export const uploadAvatar = async (userId: string, file: File) => {
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}-${Date.now()}.${fileExt}`;
  
  const { error: uploadError } = await supabase.storage
    .from('avatars')
    .upload(fileName, file);
  
  if (uploadError) {
    return { error: uploadError };
  }
  
  const { data: { publicUrl } } = supabase.storage
    .from('avatars')
    .getPublicUrl(fileName);
  
  return { data: publicUrl, error: null };
};
