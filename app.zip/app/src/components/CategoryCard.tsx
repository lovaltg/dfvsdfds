import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import type { Category } from '@/types';

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link
      to={`/category/${category.slug}`}
      className="group relative overflow-hidden rounded-xl border bg-card p-4 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="flex items-center gap-4">
        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg">
          {category.image_url ? (
            <img
              src={category.image_url}
              alt={category.name}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/20 to-primary/10">
              <span className="text-2xl font-bold text-primary">
                {category.name.charAt(0)}
              </span>
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-lg truncate">{category.name}</h3>
            {category.is_new && (
              <Badge variant="secondary" className="text-xs">
                Новое
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            {category.type === 'game' && 'Игра'}
            {category.type === 'app' && 'Приложение'}
            {category.type === 'service' && 'Услуга'}
          </p>
        </div>
      </div>
    </Link>
  );
}
