import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Star, TrendingUp } from 'lucide-react';

interface SellerWithStats {
  id: string;
  username: string;
  avatar_url: string | null;
  sales_count: number;
  positive_reviews: number;
  rating: number;
}

interface ProfileData {
  id: string;
  username: string;
  avatar_url: string | null;
}

// Предустановленные топ продавцы
const PRESET_TOP_SELLERS: SellerWithStats[] = [
  { id: 'demo1', username: 'pedalick', avatar_url: null, sales_count: 1523, positive_reviews: 1489, rating: 4.9 },
  { id: 'demo2', username: 'lovely', avatar_url: null, sales_count: 1287, positive_reviews: 1256, rating: 4.8 },
  { id: 'demo3', username: 'ghoosefun', avatar_url: null, sales_count: 987, positive_reviews: 965, rating: 4.9 },
];

export function TopSellers() {
  const [sellers, setSellers] = useState<SellerWithStats[]>(PRESET_TOP_SELLERS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTopSellers();
  }, []);

  const loadTopSellers = async () => {
    try {
      if (!isSupabaseConfigured) {
        // Demo mode - use preset data
        setLoading(false);
        return;
      }

      // Получаем профили продавцов по username
      const usernames = ['pedalick', 'lovely', 'ghoosefun'];
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('*');

      if (error) {
        console.error('Error loading profiles:', error);
        setLoading(false);
        return;
      }

      // Фильтруем профили вручную (вместо .in())
      const filteredProfiles = (profiles || []).filter((p: any) => 
        usernames.includes(p.username)
      );

      const profileMap = new Map<string, ProfileData>();
      (filteredProfiles as ProfileData[]).forEach(p => {
        profileMap.set(p.username, p);
      });

      // Статистика для каждого продавца
      const sellersWithStats: SellerWithStats[] = [];
      
      for (const username of usernames) {
        const profile = profileMap.get(username);
        if (!profile) continue;

        // Получаем количество продаж
        const { count: salesCount } = await supabase
          .from('orders')
          .select('*', { count: 'exact', head: true })
          .eq('seller_id', profile.id)
          .eq('status', 'completed');

        // Получаем отзывы
        const { data: reviews } = await supabase
          .from('reviews')
          .select('rating')
          .eq('reviewed_id', profile.id);

        const reviewList = reviews || [];
        const positiveReviews = reviewList.filter((r: any) => r.rating >= 4).length;
        const avgRating = reviewList.length > 0 
          ? reviewList.reduce((sum: number, r: any) => sum + r.rating, 0) / reviewList.length 
          : 0;

        sellersWithStats.push({
          id: profile.id,
          username: profile.username,
          avatar_url: profile.avatar_url,
          sales_count: salesCount || Math.floor(Math.random() * 1000) + 500,
          positive_reviews: positiveReviews || Math.floor(Math.random() * 500) + 400,
          rating: Number(avgRating.toFixed(1)) || 4.8,
        });
      }

      // Сортируем по продажам
      sellersWithStats.sort((a, b) => b.sales_count - a.sales_count);
      
      if (sellersWithStats.length > 0) {
        setSellers(sellersWithStats);
      }
    } catch (error) {
      console.error('Error loading top sellers:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            Топ продавцов
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4 animate-pulse">
                <div className="h-12 w-12 rounded-full bg-muted" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 w-24 bg-muted rounded" />
                  <div className="h-3 w-16 bg-muted rounded" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-500" />
          Топ продавцов
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sellers.map((seller, index) => (
            <Link
              key={seller.id}
              to={`/profile/${seller.id}`}
              className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted transition-colors"
            >
              <div className="relative">
                {seller.avatar_url ? (
                  <img
                    src={seller.avatar_url}
                    alt={seller.username}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                ) : (
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-lg font-bold text-primary">
                      {seller.username.charAt(0).toUpperCase()}
                    </span>
                  </div>
                )}
                <div className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-yellow-500 flex items-center justify-center text-xs font-bold text-white">
                  {index + 1}
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold truncate">{seller.username}</span>
                  {index === 0 && (
                    <Badge variant="default" className="bg-yellow-500 text-white text-xs">
                      #1
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                  <span className="flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    {seller.sales_count} продаж
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    {seller.rating}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
