import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { Home } from '@/pages/Home';
import { Category } from '@/pages/Category';
import { Lot } from '@/pages/Lot';
import { Profile } from '@/pages/Profile';
import { Chats } from '@/pages/Chats';
import { Finances } from '@/pages/Finances';
import { Auth } from '@/pages/Auth';
import { Sell } from '@/pages/Sell';
import { Games } from '@/pages/Games';
import { MyLots } from '@/pages/MyLots';
import { Toaster } from '@/components/ui/sonner';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/category/:slug" element={<Category />} />
            <Route path="/lot/:id" element={<Lot />} />
            <Route path="/profile/:id" element={<Profile />} />
            <Route path="/chats" element={<Chats />} />
            <Route path="/finances" element={<Finances />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/auth/callback" element={<Navigate to="/" />} />
            <Route path="/sell" element={<Sell />} />
            <Route path="/games" element={<Games />} />
            <Route path="/apps" element={<Games />} />
            <Route path="/mobile-games" element={<Games />} />
            <Route path="/my-lots" element={<MyLots />} />
            <Route path="/lots" element={<Games />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </BrowserRouter>
        <Toaster />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
